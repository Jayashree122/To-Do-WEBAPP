document.addEventListener('DOMContentLoaded', () => {
    const taskInput = document.getElementById('taskInput');
    const addTaskBtn = document.getElementById('addTaskBtn');
    const pendingTasks = document.getElementById('pendingTasks');
    const completedTasks = document.getElementById('completedTasks');

    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];

    function saveTasks() {
        localStorage.setItem('tasks', JSON.stringify(tasks));
    }

    function renderTasks() {
        pendingTasks.innerHTML = '';
        completedTasks.innerHTML = '';
        
        tasks.forEach((task, index) => {
            const li = document.createElement('li');
            li.textContent = `${task.text} - ${task.date}`;
            
            if (task.completed) {
                li.classList.add('completed');
                const undoBtn = document.createElement('button');
                undoBtn.textContent = 'Undo';
                undoBtn.className = 'complete';
                undoBtn.addEventListener('click', () => markAsPending(index));
                li.appendChild(undoBtn);
                completedTasks.appendChild(li);
            } else {
                const completeBtn = document.createElement('button');
                completeBtn.textContent = 'Complete';
                completeBtn.className = 'complete';
                completeBtn.addEventListener('click', () => markAsComplete(index));
                li.appendChild(completeBtn);
                pendingTasks.appendChild(li);
            }

            const editBtn = document.createElement('button');
            editBtn.textContent = 'Edit';
            editBtn.className = 'edit';
            editBtn.addEventListener('click', () => editTask(index));
            li.appendChild(editBtn);

            const deleteBtn = document.createElement('button');
            deleteBtn.textContent = 'Delete';
            deleteBtn.className = 'delete';
            deleteBtn.addEventListener('click', () => deleteTask(index));
            li.appendChild(deleteBtn);
        });
    }

    function addTask() {
        const taskText = taskInput.value.trim();
        if (taskText !== '') {
            const task = {
                text: taskText,
                completed: false,
                date: new Date().toLocaleString(),
            };
            tasks.push(task);
            saveTasks();
            renderTasks();
            taskInput.value = '';
        }
    }

    function deleteTask(index) {
        tasks.splice(index, 1);
        saveTasks();
        renderTasks();
    }

    function editTask(index) {
        const newTaskText = prompt('Edit your task:', tasks[index].text);
        if (newTaskText !== null) {
            tasks[index].text = newTaskText;
            tasks[index].date = new Date().toLocaleString();
            saveTasks();
            renderTasks();
        }
    }

    function markAsComplete(index) {
        tasks[index].completed = true;
        tasks[index].date = new Date().toLocaleString();
        saveTasks();
        renderTasks();
    }

    function markAsPending(index) {
        tasks[index].completed = false;
        saveTasks();
        renderTasks();
    }

    addTaskBtn.addEventListener('click', addTask);
    taskInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            addTask();
        }
    });

    renderTasks();
});
